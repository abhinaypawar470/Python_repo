l1 = [1, 8, 7, 2, 21, 15]
print(l1)
# l1.sort() # sorts the list
# l1.reverse() # reverses the list
#l1.append(45) # adds 45 at the end of the list 
# l1.insert(2, 544) # inserts 544 at index 2
# l1.pop(2) # removes element at index 2
l1.remove(21) # removes 21 from the list
print(l1)