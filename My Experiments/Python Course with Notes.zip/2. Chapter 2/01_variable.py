a_122 = '''harry'''
# a = 'harry'
# a = "harry"
b = 345
c = 45.32
d = True
# d = None

# Printing the variables
print(a)
print(b)
print(c)
print(d)

# Printing the type of variables
print(type(a))
print(type(b))
print(type(c))
print(type(d))
