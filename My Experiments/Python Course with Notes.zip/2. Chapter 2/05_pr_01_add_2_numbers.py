a = 30
b = 15
print("The sum of a and b is", a + b)