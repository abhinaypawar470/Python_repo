st = "This is a string with double  spaces  ok"

st = st.replace("  ", " ")
print(st)