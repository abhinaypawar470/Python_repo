from playsound import playsound
playsound('D:\\MyData\\Business\\code playground\\Python Course With Notes\\1. Chapter 1\\play.mp3')
